from __future__ import annotations


from rich.align import Align
from rich.console import Console, RenderableType, Group
from rich.layout import Layout
from rich.panel import Panel
from rich.text import Text


class OnboardingUI:
    """
    Minimalist "Studio Dashboard" UI engine for VYN onboarding.
    Uses Black, White & Gray high-contrast design with centered spatial layouts.
    """

    def __init__(self):
        self.console = Console()
        self._border_style = "dim #444444"  # Subtle thin dark-gray border
        self._header_style = "bold #ffffff"  # Crisp pure white headings
        self._dim_style = "#888888"  # Muted gray descriptions/subtitles

    def clear(self):
        """Clear the terminal screen."""
        self.console.clear()

    def create_slab(
        self,
        title: str,
        content: RenderableType,
        subtitle: str | None = None,
        width: int = 60,
    ) -> Align:
        """Create a centered panel 'slab' with the given content."""
        # Header text
        header = Text(f"\n{title.upper()}\n", style=self._header_style, justify="center")
        
        # Combine everything into a vertical renderable
        body = []
        body.append(header)
        
        # Thin divider separating title from body content
        divider = Text("─" * (width - 6), style=self._border_style, justify="center")
        body.append(divider)
        body.append(Text("\n"))
        
        body.append(content)
        
        if subtitle:
            body.append(Text("\n"))
            body.append(divider)
            body.append(Text(f"\n{subtitle}", style=self._dim_style, justify="center"))
        body.append(Text("\n"))

        # Create the panel (The Slab) with spacious padding
        panel = Panel(
            Align.center(Group(*body)),
            border_style=self._border_style,
            padding=(2, 4),
            width=width,
        )

        # Center vertically and horizontally
        return Align.center(panel, vertical="middle")

    def render_step(self, title: str, content: RenderableType, subtitle: str | None = None):
        """Render a single step of the onboarding."""
        self.clear()
        slab = self.create_slab(title, content, subtitle)
        self.console.print(slab)

    def prompt(self, text: str, default: str = "", password: bool = False) -> str:
        """A minimalist prompt styled to match the slab aesthetic with elegant arrow and muted defaults."""
        prompt_text = Text("  ◆ ", style="bold #ffffff")
        prompt_text.append(text, style="bold #ffffff")
        if default:
            prompt_text.append(f" (default: {default})", style=self._dim_style)
        prompt_text.append(" › ", style="bold #ffffff")
        val = self.console.input(prompt_text, password=password).strip()
        return val or default

    def prompt_choice(self, title: str, choices: list[str], subtitle: str | None = None) -> int:
        """
        Render choices and let the user select using Up/Down arrow keys and Enter.
        Returns the selected choice index. Supports Windows, Unix, and safe non-TTY fallbacks.
        """
        import sys
        import os

        # Helper: Render standard fallback prompt
        def fallback_prompt() -> int:
            from rich.table import Table
            table = Table(show_header=False, box=None, padding=(0, 2))
            for i, choice in enumerate(choices, 1):
                table.add_row(Text(f"{i}.", style="dim"), Text(choice, style="bold white"))
            self.render_step(title, table, subtitle=subtitle)
            val = self.prompt(f"Select option [1-{len(choices)}]", default="1")
            try:
                return max(0, min(len(choices) - 1, int(val) - 1))
            except ValueError:
                return 0

        # If not interactive/a TTY, fallback immediately
        if not sys.stdin.isatty():
            return fallback_prompt()

        current_index = 0

        # Helper to read raw keypress without blocking other processes, cross-platform
        def get_key_blocking() -> str:
            if os.name == 'nt':
                import msvcrt
                ch = msvcrt.getch()
                if ch in (b'\x00', b'\xe0'):
                    ch2 = msvcrt.getch()
                    if ch2 == b'H':
                        return 'up'
                    elif ch2 == b'P':
                        return 'down'
                elif ch in (b'\r', b'\n'):
                    return 'enter'
                elif ch == b'\x03':  # Ctrl+C
                    raise KeyboardInterrupt()
                return 'other'
            else:
                import termios
                import tty
                fd = sys.stdin.fileno()
                old_settings = termios.tcgetattr(fd)
                try:
                    tty.setraw(fd)
                    ch = sys.stdin.read(1)
                    if ch == '\x1b':
                        ch2 = sys.stdin.read(2)
                        if ch2 == '[A':
                            return 'up'
                        elif ch2 == '[B':
                            return 'down'
                    elif ch in ('\r', '\n'):
                        return 'enter'
                    elif ch == '\x03':  # Ctrl+C
                        raise KeyboardInterrupt()
                finally:
                    termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
                return 'other'

        try:
            while True:
                # Build selection visual table
                from rich.table import Table
                table = Table(show_header=False, box=None, padding=(0, 2))
                for idx, choice in enumerate(choices):
                    if idx == current_index:
                        table.add_row(Text("  ▶  ", style="bold #ffffff"), Text(choice, style="bold #ffffff"))
                    else:
                        table.add_row(Text("     ", style=self._dim_style), Text(choice, style=self._dim_style))

                # Inject dynamic helper instruction in the subtitle
                full_subtitle = subtitle or ""
                if full_subtitle:
                    full_subtitle += "  •  (↑/↓ to navigate, Enter to select)"
                else:
                    full_subtitle = "(↑/↓ to navigate, Enter to select)"

                self.render_step(title, table, subtitle=full_subtitle)

                key = get_key_blocking()
                if key == 'up':
                    current_index = (current_index - 1) % len(choices)
                elif key == 'down':
                    current_index = (current_index + 1) % len(choices)
                elif key == 'enter':
                    return current_index
        except Exception:
            # Fallback for any unexpected environment or standard terminal issues
            return fallback_prompt()

